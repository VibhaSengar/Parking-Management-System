# keylogger-project
I developed  a python code which will simply run in the command prompt and it will send the key logging information through the email address I provide. Basically we will get to know for which purpose our system is being used by someone else.

                SYSTEM SURVEILLANCE USING KEYLOGGER 
INTRODUCTION:
            In many companies now-a-days data security and data recovery is the most important factor. So there are many cases where data recovery is required. For these kinds of problems keylogger is one of the best solutions which is often referred to as keylogging or keyboard capturing.
Keyboard capturing is the action of recording the keys stroke on a keyboard, typically covertly, so that the person using the keyboard is unaware that their actions are being monitored. Using keylogger application users can retrieve data when working file is damaged due to several reasons like loss of power etc. 
This is a surveillance application used to track the users which logs keystrokes; uses log files to retrieve information. Using this application we can recall forgotten email or URL. In this keylogger project, whenever the user types something through the keyboard, the keystrokes are captured and mailed to the mail id of admin without the knowledge of the user within the time set. 
OBJECTIVE:
             The purpose of this application is to keep tracks on every key that is typed through the keyboard and send it to the admin through the mail server in the time set or given. It provides confidentiality as well as data recovery to all the IT infrastructures in need. 
HARDWARE REQUIREMENTS:
Operating system                 :          Any Operating System
RAM			           :         512MB (minimum requirement)
Hard Disk		           :         1GB working space (minimum requirement)

SOFTWARE REQUIREMENTS:
Languages                           :          Python
 Tools                                   :          PyCharm, Python 3.8.0
 Technology                         :         Advanced programming using Python 







  OUTPUT:
1.	TYPING THROUGH THE KEYBOARD:   
2.	MAIL IN ADMIN’S MOBILE DEVICE:





